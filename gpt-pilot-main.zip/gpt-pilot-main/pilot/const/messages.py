CHECK_AND_CONTINUE = 'If something is wrong, tell me or type "continue" to continue.'
WHEN_USER_DONE = 'Once you\'re done, type "continue"'
